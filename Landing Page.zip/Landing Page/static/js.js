
alert('You just clicked me')
